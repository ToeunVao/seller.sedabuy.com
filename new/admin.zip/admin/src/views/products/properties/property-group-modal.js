import React, { useEffect, useState } from 'react';
import { Button, Form, Input, Modal } from 'antd';
import { useTranslation } from 'react-i18next';
import LanguageList from 'components/language-list';
import { shallowEqual, useDispatch, useSelector } from 'react-redux';
import propertyService from 'services/property';
import { toast } from 'react-toastify';
import { fetchPropertyGroups } from 'redux/slices/propertyGroup';
import getTranslationFields from 'helpers/getTranslationFields';
import Loading from 'components/loading';
import { setRefetch } from '../../../redux/slices/menu';

export default function PropertyGroupModal({ modal, handleCancel, onSuccess }) {
  const { t } = useTranslation();
  const [form] = Form.useForm();
  const dispatch = useDispatch();

  const { languages, defaultLang } = useSelector(
    (state) => state.formLang,
    shallowEqual,
  );
  const { activeMenu } = useSelector((state) => state.menu, shallowEqual);

  const [loadingBtn, setLoadingBtn] = useState(false);
  const [loading, setLoading] = useState(false);

  function fetchGroup(id) {
    setLoading(true);
    propertyService
      .getGroupById(id)
      .then((res) => {
        const data = res.data;
        form.setFieldsValue({ ...data, ...getLanguageFields(data) });
      })
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    if (modal?.id) {
      fetchGroup(modal.id);
    }
  }, [modal]);

  function createPropertyGroup(body) {
    setLoadingBtn(true);
    propertyService
      .createGroup(body)
      .then(() => {
        toast.success(t('successfully.created'));
        handleCancel();
        dispatch(setRefetch(activeMenu));
        !!onSuccess && onSuccess();
      })
      .finally(() => setLoadingBtn(false));
  }

  const onFinish = (values) => {
    const body = {
      title: getTranslationFields(languages, values),
      type: 'text',
    };
    if (modal?.id) {
      updatePropertyGroup(modal?.id, body);
    } else {
      createPropertyGroup(body);
    }
  };

  function updatePropertyGroup(id, body) {
    setLoadingBtn(true);
    propertyService
      .updateGroup(id, body)
      .then(() => {
        toast.success(t('successfully.updated'));
        dispatch(setRefetch(activeMenu));
        handleCancel();
      })
      .finally(() => setLoadingBtn(false));
  }

  function getLanguageFields(data) {
    if (!data) {
      return {};
    }
    const { translations } = data;
    const result = languages.map((item) => ({
      [`title[${item.locale}]`]: translations.find(
        (el) => el.locale === item.locale,
      )?.title,
    }));
    return Object.assign({}, ...result);
  }

  return (
    <Modal
      title={modal?.id ? t('edit.property.group') : t('add.property.group')}
      visible={!!modal}
      onCancel={handleCancel}
      footer={[
        <Button key='cancel-button-group' type='default' onClick={handleCancel}>
          {t('cancel')}
        </Button>,
        <Button
          key='save-button-group'
          type='primary'
          onClick={() => form.submit()}
          loading={loadingBtn}
        >
          {t('save')}
        </Button>,
      ]}
    >
      {!loading ? (
        <>
          <div className='d-flex justify-content-end'>
            <LanguageList />
          </div>
          <Form
            layout='vertical'
            name='property-group'
            form={form}
            onFinish={onFinish}
          >
            {languages.map((item) => (
              <Form.Item
                key={'title' + item.locale}
                rules={[
                  {
                    required: item.locale === defaultLang,
                    message: t('required'),
                  },
                ]}
                name={`title[${item.locale}]`}
                label={t('title')}
                hidden={item.locale !== defaultLang}
              >
                <Input placeholder={t('title')} />
              </Form.Item>
            ))}
          </Form>
        </>
      ) : (
        <Loading />
      )}
    </Modal>
  );
}
